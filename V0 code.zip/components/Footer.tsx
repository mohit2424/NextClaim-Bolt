export function Footer() {
  return (
    <footer className="w-full border-t bg-background mt-8">
      <div className="container mx-auto py-2 text-center text-sm text-muted-foreground">Powered by Sails Software</div>
    </footer>
  )
}

