"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Overview } from "@/components/Overview"
import { ClaimsOverview } from "@/components/ClaimsOverview"
import { InteractiveClaimsPieChart } from "@/components/InteractiveClaimsPieChart"
import { InteractiveClaimsBarChart } from "@/components/InteractiveClaimsBarChart"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { X } from "lucide-react"
import { ElasticSearch } from "@/components/ElasticSearch"
import { HearingRepDialog } from "@/components/HearingRepDialog"
import { RepProfileDialog } from "@/components/RepProfileDialog"

const recentClaims = [
  {
    id: "CLM001",
    claimantName: "John Doe",
    status: "Pending",
    dateFiled: "2024-03-15",
    employer: "Tech Corp",
    benefit: "$450",
  },
  {
    id: "CLM002",
    claimantName: "Jane Smith",
    status: "Approved",
    dateFiled: "2024-03-14",
    employer: "Retail Inc",
    benefit: "$400",
  },
  {
    id: "CLM003",
    claimantName: "Bob Johnson",
    status: "In Progress",
    dateFiled: "2024-03-13",
    employer: "Manufacturing Co",
    benefit: "$500",
  },
  {
    id: "CLM004",
    claimantName: "Alice Brown",
    status: "Rejected",
    dateFiled: "2024-03-12",
    employer: "Service LLC",
    benefit: "$0",
  },
  {
    id: "CLM005",
    claimantName: "Charlie Davis",
    status: "Pending",
    dateFiled: "2024-03-11",
    employer: "Finance Corp",
    benefit: "$475",
  },
  {
    id: "CLM006",
    claimantName: "Eva Wilson",
    status: "In Progress",
    dateFiled: "2024-03-10",
    employer: "Education Inc",
    benefit: "$425",
  },
  {
    id: "CLM007",
    claimantName: "Frank Miller",
    status: "Approved",
    dateFiled: "2024-03-09",
    employer: "Healthcare Co",
    benefit: "$550",
  },
  {
    id: "CLM008",
    claimantName: "Grace Lee",
    status: "Pending",
    dateFiled: "2024-03-08",
    employer: "Logistics LLC",
    benefit: "$480",
  },
  {
    id: "CLM009",
    claimantName: "Henry Taylor",
    status: "In Progress",
    dateFiled: "2024-03-07",
    employer: "Construction Inc",
    benefit: "$525",
  },
  {
    id: "CLM010",
    claimantName: "Ivy Chen",
    status: "Rejected",
    dateFiled: "2024-03-06",
    employer: "Marketing Corp",
    benefit: "$0",
  },
]

const initialHearingReps = [
  {
    id: "HR001",
    name: "Alice Johnson",
    type: "Internal",
    winRate: "78%",
    experience: "5 years",
    specialization: "Employment Law",
  },
  {
    id: "HR002",
    name: "Bob Smith",
    type: "Internal",
    winRate: "82%",
    experience: "8 years",
    specialization: "Labor Disputes",
  },
  {
    id: "HR003",
    name: "Carol Williams",
    type: "External",
    winRate: "85%",
    experience: "10 years",
    specialization: "Wrongful Termination",
  },
  {
    id: "HR004",
    name: "David Brown",
    type: "External",
    winRate: "80%",
    experience: "7 years",
    specialization: "Workplace Discrimination",
  },
  {
    id: "HR005",
    name: "Eva Martinez",
    type: "Internal",
    winRate: "76%",
    experience: "4 years",
    specialization: "Unemployment Benefits",
  },
  {
    id: "HR006",
    name: "Frank Lee",
    type: "External",
    winRate: "83%",
    experience: "9 years",
    specialization: "Labor Law",
  },
  {
    id: "HR007",
    name: "Grace Kim",
    type: "Internal",
    winRate: "79%",
    experience: "6 years",
    specialization: "Employee Rights",
  },
  {
    id: "HR008",
    name: "Henry Wilson",
    type: "External",
    winRate: "81%",
    experience: "8 years",
    specialization: "Workplace Safety",
  },
]

const cards = [
  {
    title: "Total Claims",
    value: 1200,
    href: "/claims",
    gradient: "from-blue-500 to-blue-600",
  },
  {
    title: "Pending Claims",
    value: 300,
    href: "/claims?status=pending",
    gradient: "from-yellow-500 to-yellow-600",
  },
  {
    title: "In Progress",
    value: 150,
    href: "/claims?status=in-progress",
    gradient: "from-purple-500 to-purple-600",
  },
  {
    title: "Approved Claims",
    value: 650,
    href: "/claims?status=approved",
    gradient: "from-green-500 to-green-600",
  },
  {
    title: "Rejected Claims",
    value: 100,
    href: "/claims?status=rejected",
    gradient: "from-red-500 to-red-600",
  },
]

export default function DashboardPage() {
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null)
  const [hearingReps, setHearingReps] = useState(initialHearingReps)
  const [deletedReps, setDeletedReps] = useState<typeof initialHearingReps>([])
  const [showHearingRepDialog, setShowHearingRepDialog] = useState(false)
  const [hearingRepDialogType, setHearingRepDialogType] = useState<"internal" | "external">("internal")
  const [searchItems, setSearchItems] = useState(
    recentClaims.map((claim) => ({ id: claim.id, name: claim.claimantName })),
  )
  const [selectedReps, setSelectedReps] = useState<string[]>([])
  const [showRepProfile, setShowRepProfile] = useState(false)
  const [selectedRep, setSelectedRep] = useState<(typeof initialHearingReps)[0] | null>(null)

  const handleAddHearingRep = (newRep: Omit<(typeof initialHearingReps)[0], "id">) => {
    const rep = {
      ...newRep,
      id: `HR${hearingReps.length + deletedReps.length + 1}`,
    }
    setHearingReps([...hearingReps, rep])
  }

  const handleRemoveHearingRep = (id: string) => {
    const repToRemove = hearingReps.find((rep) => rep.id === id)
    if (repToRemove) {
      setDeletedReps([...deletedReps, repToRemove])
      setHearingReps(hearingReps.filter((rep) => rep.id !== id))
    }
  }

  const handleRestoreHearingRep = (id: string) => {
    const repToRestore = deletedReps.find((rep) => rep.id === id)
    if (repToRestore) {
      setHearingReps([...hearingReps, repToRestore])
      setDeletedReps(deletedReps.filter((rep) => rep.id !== id))
    }
  }

  const openHearingRepDialog = (type: "internal" | "external") => {
    setHearingRepDialogType(type)
    setShowHearingRepDialog(true)
  }

  const handleViewProfile = (rep: (typeof initialHearingReps)[0]) => {
    setSelectedRep(rep)
    setShowRepProfile(true)
  }

  const handleSearch = (query: string) => {
    console.log("Searching for:", query)
  }

  const handleSelectRep = (id: string) => {
    setSelectedReps((prev) => (prev.includes(id) ? prev.filter((repId) => repId !== id) : [...prev, id]))
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <div>
          <h2 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Welcome to Dashboard
          </h2>
          <p className="text-muted-foreground">Manage and review unemployment claims</p>
        </div>
        <ElasticSearch items={searchItems} onSearch={handleSearch} className="w-64" />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        {cards.map((card) => (
          <Link key={card.title} href={card.href}>
            <Card className="relative overflow-hidden transition-all hover:shadow-lg">
              <div className={`absolute inset-0 opacity-10 bg-gradient-to-br ${card.gradient}`} />
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{card.value}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Claims Overview</CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <InteractiveClaimsBarChart onStatusSelect={setSelectedStatus} />
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Claims Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <InteractiveClaimsPieChart onStatusSelect={setSelectedStatus} />
          </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7 mt-8">
        <Card className="col-span-7">
          {" "}
          {/* Update: Changed col-span from 4 to 7 */}
          <CardHeader>
            <CardTitle>Recent Claims</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Claim ID</TableHead>
                    <TableHead>Claimant Name</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date Filed</TableHead>
                    <TableHead>Employer</TableHead>
                    <TableHead>Benefit</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentClaims.map((claim) => (
                    <TableRow key={claim.id}>
                      <TableCell>{claim.id}</TableCell>
                      <TableCell>{claim.claimantName}</TableCell>
                      <TableCell>{claim.status}</TableCell>
                      <TableCell>{claim.dateFiled}</TableCell>
                      <TableCell>{claim.employer}</TableCell>
                      <TableCell>{claim.benefit}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/claims/${claim.id}`}>View</Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
      {selectedStatus && <ClaimsOverview status={selectedStatus} />}

      <HearingRepDialog
        open={showHearingRepDialog}
        onOpenChange={setShowHearingRepDialog}
        type={hearingRepDialogType}
        hearingReps={hearingReps.filter((rep) => rep.type.toLowerCase() === hearingRepDialogType)}
        deletedReps={deletedReps.filter((rep) => rep.type.toLowerCase() === hearingRepDialogType)}
        onAddRep={handleAddHearingRep}
        onRemoveRep={handleRemoveHearingRep}
        onRestoreRep={handleRestoreHearingRep}
        selectedReps={selectedReps}
        onSelectRep={handleSelectRep}
      />

      <RepProfileDialog rep={selectedRep} open={showRepProfile} onOpenChange={setShowRepProfile} />
    </div>
  )
}

// Placeholder for HearingRepDialog component -  Implementation needed separately.
const HearingRepDialog = ({
  open,
  onOpenChange,
  type,
  hearingReps,
  deletedReps,
  onAddRep,
  onRemoveRep,
  onRestoreRep,
  selectedReps,
  onSelectRep,
}: any) => {
  return <div>HearingRepDialog Component - Implementation needed</div>
}

