"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { ChevronLeft, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"

// This is mock data. In a real application, you would fetch this from an API.
const allClaims = [
  {
    id: "CLM001",
    claimantName: "John Doe",
    dateSubmitted: "2024-03-15",
    status: "pending",
    lastUpdated: "2024-03-16",
    weeklyBenefit: "$450",
    employer: "Tech Corp Inc",
    dueDate: "2024-03-30",
  },
  {
    id: "CLM002",
    claimantName: "Jane Smith",
    dateSubmitted: "2024-03-10",
    status: "in-progress",
    lastUpdated: "2024-03-14",
    weeklyBenefit: "$500",
    employer: "Marketing Solutions LLC",
    dueDate: "2024-03-25",
  },
  {
    id: "CLM003",
    claimantName: "Alice Johnson",
    dateSubmitted: "2024-03-05",
    status: "approved",
    lastUpdated: "2024-03-12",
    weeklyBenefit: "$400",
    employer: "Retail Giants Co.",
    dueDate: "2024-03-20",
  },
  {
    id: "CLM004",
    claimantName: "Bob Brown",
    dateSubmitted: "2024-03-01",
    status: "rejected",
    lastUpdated: "2024-03-08",
    weeklyBenefit: "$0",
    employer: "City Services Department",
    dueDate: "2024-03-15",
  },
  {
    id: "CLM005",
    claimantName: "Charlie Davis",
    dateSubmitted: "2024-02-28",
    status: "pending",
    lastUpdated: "2024-03-02",
    weeklyBenefit: "$475",
    employer: "Education First Institute",
    dueDate: "2024-03-14",
  },
  {
    id: "CLM006",
    claimantName: "Eva Wilson",
    dateSubmitted: "2024-02-25",
    status: "in-progress",
    lastUpdated: "2024-03-01",
    weeklyBenefit: "$525",
    employer: "Healthcare Solutions Inc.",
    dueDate: "2024-03-11",
  },
  {
    id: "CLM007",
    claimantName: "Frank Miller",
    dateSubmitted: "2024-02-20",
    status: "approved",
    lastUpdated: "2024-02-27",
    weeklyBenefit: "$450",
    employer: "Construction Experts Ltd.",
    dueDate: "2024-03-06",
  },
  {
    id: "CLM008",
    claimantName: "Grace Lee",
    dateSubmitted: "2024-02-15",
    status: "rejected",
    lastUpdated: "2024-02-22",
    weeklyBenefit: "$0",
    employer: "Financial Services Group",
    dueDate: "2024-03-01",
  },
  {
    id: "CLM009",
    claimantName: "Henry Taylor",
    dateSubmitted: "2024-02-10",
    status: "pending",
    lastUpdated: "2024-02-12",
    weeklyBenefit: "$490",
    employer: "Logistics Pro Company",
    dueDate: "2024-02-25",
  },
  {
    id: "CLM010",
    claimantName: "Ivy Chen",
    dateSubmitted: "2024-02-05",
    status: "in-progress",
    lastUpdated: "2024-02-09",
    weeklyBenefit: "$510",
    employer: "Software Innovations Inc.",
    dueDate: "2024-02-20",
  },
  {
    id: "CLM011",
    claimantName: "Jack Wilson",
    dateSubmitted: "2024-01-30",
    status: "approved",
    lastUpdated: "2024-02-06",
    weeklyBenefit: "$480",
    employer: "Manufacturing Solutions Co.",
    dueDate: "2024-02-14",
  },
  {
    id: "CLM012",
    claimantName: "Karen Lopez",
    dateSubmitted: "2024-01-25",
    status: "rejected",
    lastUpdated: "2024-02-01",
    weeklyBenefit: "$0",
    employer: "Hospitality Services LLC",
    dueDate: "2024-02-09",
  },
  {
    id: "CLM013",
    claimantName: "Liam Wright",
    dateSubmitted: "2024-01-20",
    status: "pending",
    lastUpdated: "2024-01-22",
    weeklyBenefit: "$495",
    employer: "Green Energy Systems",
    dueDate: "2024-02-04",
  },
  {
    id: "CLM014",
    claimantName: "Mia Rodriguez",
    dateSubmitted: "2024-01-15",
    status: "in-progress",
    lastUpdated: "2024-01-19",
    weeklyBenefit: "$520",
    employer: "Data Analytics Corp",
    dueDate: "2024-01-30",
  },
  {
    id: "CLM015",
    claimantName: "Noah Thompson",
    dateSubmitted: "2024-01-10",
    status: "approved",
    lastUpdated: "2024-01-17",
    weeklyBenefit: "$460",
    employer: "Automotive Innovations",
    dueDate: "2024-01-25",
  },
]

export default function ClaimsPage() {
  const searchParams = useSearchParams()
  const [status, setStatus] = useState(searchParams.get("status") || "all")
  const [claims, setClaims] = useState(allClaims)
  const [sortField, setSortField] = useState("dateSubmitted")
  const [sortDirection, setSortDirection] = useState("desc")
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    let filteredClaims = allClaims

    // Filter by status
    if (status !== "all") {
      filteredClaims = filteredClaims.filter((claim) => claim.status === status)
    }

    // Filter by search term
    if (searchTerm) {
      filteredClaims = filteredClaims.filter(
        (claim) =>
          claim.claimantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          claim.id.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    // Sort claims
    filteredClaims.sort((a, b) => {
      if (a[sortField] < b[sortField]) return sortDirection === "asc" ? -1 : 1
      if (a[sortField] > b[sortField]) return sortDirection === "asc" ? 1 : -1
      return 0
    })

    // Get claims from the last 15 days
    const fifteenDaysAgo = new Date()
    fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15)
    const recentClaims = filteredClaims.filter((claim) => new Date(claim.dateSubmitted) >= fifteenDaysAgo)
    const olderClaims = filteredClaims.filter((claim) => new Date(claim.dateSubmitted) < fifteenDaysAgo)

    setClaims([...recentClaims, ...olderClaims])
  }, [status, sortField, sortDirection, searchTerm])

  const handleStatusChange = (newStatus: string) => {
    setStatus(newStatus)
  }

  const handleSort = (field: string) => {
    if (field === sortField) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard">
              <ChevronLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Claims List
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <Input
            placeholder="Search claims..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-[200px]"
          />
          <Select value={status} onValueChange={handleStatusChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Claims</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="cursor-pointer" onClick={() => handleSort("id")}>
                Claim ID
                {sortField === "id" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("claimantName")}>
                Claimant Name
                {sortField === "claimantName" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("dateSubmitted")}>
                Date Submitted
                {sortField === "dateSubmitted" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("lastUpdated")}>
                Last Updated
                {sortField === "lastUpdated" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("status")}>
                Status
                {sortField === "status" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("weeklyBenefit")}>
                Weekly Benefit
                {sortField === "weeklyBenefit" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("employer")}>
                Employer
                {sortField === "employer" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => handleSort("dueDate")}>
                Due Date
                {sortField === "dueDate" &&
                  (sortDirection === "asc" ? (
                    <ChevronUp className="inline ml-1" />
                  ) : (
                    <ChevronDown className="inline ml-1" />
                  ))}
              </TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {claims.map((claim) => (
              <TableRow key={claim.id}>
                <TableCell className="font-medium">{claim.id}</TableCell>
                <TableCell>{claim.claimantName}</TableCell>
                <TableCell>{claim.dateSubmitted}</TableCell>
                <TableCell>{claim.lastUpdated}</TableCell>
                <TableCell>
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-semibold
                    ${
                      claim.status === "pending"
                        ? "bg-yellow-200 text-yellow-800"
                        : claim.status === "in-progress"
                          ? "bg-blue-200 text-blue-800"
                          : claim.status === "approved"
                            ? "bg-green-200 text-green-800"
                            : "bg-red-200 text-red-800"
                    }`}
                  >
                    {claim.status.charAt(0).toUpperCase() + claim.status.slice(1)}
                  </span>
                </TableCell>
                <TableCell>{claim.weeklyBenefit}</TableCell>
                <TableCell>{claim.employer}</TableCell>
                <TableCell>{claim.dueDate}</TableCell>
                <TableCell>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/claims/${claim.id}`}>View Details</Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

