"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ChevronLeft, Edit2, Save, X, Upload, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Checkbox } from "@/components/ui/checkbox"

const claimStates = [
  { value: "initial", label: "Initial Review" },
  { value: "determination", label: "Determination" },
  { value: "protest", label: "Protest" },
  { value: "appeal", label: "Appeal" },
  { value: "hearing", label: "Hearing" },
]

const initialHearingReps = [
  {
    id: "HR001",
    name: "Alice Johnson",
    type: "internal",
    experience: "5 years",
    hourlyCharge: "$150",
    winRate: "78%",
    specialization: "Employment Law",
    languages: ["English", "Spanish"],
    education: "J.D., Stanford Law School",
    caseHistory: "Successfully represented 50+ unemployment claims",
  },
  {
    id: "HR002",
    name: "Bob Smith",
    type: "internal",
    experience: "8 years",
    hourlyCharge: "$175",
    winRate: "82%",
    specialization: "Labor Disputes",
    languages: ["English", "French"],
    education: "J.D., Harvard Law School",
    caseHistory: "Handled over 100 unemployment claim hearings",
  },
  {
    id: "HR003",
    name: "Carol Williams",
    type: "external",
    experience: "10 years",
    hourlyCharge: "$200",
    winRate: "85%",
    specialization: "Wrongful Termination",
    languages: ["English", "Mandarin"],
    education: "J.D., Yale Law School",
    caseHistory: "Won 90% of appealed unemployment claims",
  },
  {
    id: "HR004",
    name: "David Brown",
    type: "external",
    experience: "7 years",
    hourlyCharge: "$180",
    winRate: "80%",
    specialization: "Workplace Discrimination",
    languages: ["English", "German"],
    education: "J.D., Columbia Law School",
    caseHistory: "Specializes in complex unemployment cases",
  },
]

// Dummy data for a single claim
const dummyClaimData = {
  id: "CLM001",
  claimantName: "John Doe",
  age: "35",
  email: "john.doe@example.com",
  phone: "(555) 123-4567",
  address: "123 Main St",
  state: "California",
  zipCode: "90210",
  filingDate: "2024-03-01",
  lastWorked: "2024-02-28",
  reason: "Company downsizing",
  weeklyBenefit: "$450",
  currentState: "initial",
  employerName: "Tech Corp Inc",
  employerAddress: "456 Business Ave, Suite 100",
  contactPerson: "Jane Smith",
  employerPhone: "(555) 987-6543",
  status: "pending",
  documents: [
    { name: "identification.pdf", uploadDate: "2024-03-01" },
    { name: "employment_letter.pdf", uploadDate: "2024-03-02" },
  ],
  notes: [
    { date: "2024-03-03", content: "Initial review completed. Awaiting additional documentation." },
    { date: "2024-03-05", content: "Contacted claimant for additional information." },
  ],
  timeline: [
    { title: "Claim Filed", date: "2024-03-01" },
    { title: "Initial Review", date: "2024-03-03" },
    { title: "Additional Documentation Requested", date: "2024-03-05" },
    { title: "Documentation Received", date: "2024-03-10" },
    { title: "Determination in Progress", date: "2024-03-15" },
  ],
}

export default function ClaimDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [claimState, setClaimState] = useState(dummyClaimData.currentState)
  const [selectedHearingReps, setSelectedHearingReps] = useState<string[]>([])
  const [notes, setNotes] = useState("")
  const [showNotesDialog, setShowNotesDialog] = useState(false)
  const [claimStatus, setClaimStatus] = useState(dummyClaimData.status)
  const [claimData, setClaimData] = useState(dummyClaimData)
  const [showRepProfileDialog, setShowRepProfileDialog] = useState(false)
  const [selectedRepProfile, setSelectedRepProfile] = useState<(typeof initialHearingReps)[0] | null>(null)
  const [repType, setRepType] = useState<"internal" | "external">("internal")
  const [hearingReps, setHearingReps] = useState(initialHearingReps)

  const filteredHearingReps = hearingReps.filter((rep) => rep.type === repType)

  useEffect(() => {
    // This is a placeholder. In a real application, you would fetch the claim data from an API
    setClaimData(dummyClaimData)
    setClaimStatus(dummyClaimData.status)
    setClaimState(dummyClaimData.currentState)
  }, [])

  const toggleEdit = () => {
    setIsEditing(!isEditing)
  }

  const handleSave = () => {
    // Here you would typically save the changes
    setIsEditing(false)
  }

  const handleAddNote = () => {
    const newNote = {
      date: new Date().toISOString().split("T")[0],
      content: notes,
    }
    setClaimData((prevData) => ({
      ...prevData,
      notes: [...prevData.notes, newNote],
    }))
    setNotes("")
    setShowNotesDialog(false)
  }

  const handleRepSelection = (repId: string) => {
    setSelectedHearingReps((prev) => (prev.includes(repId) ? prev.filter((id) => id !== repId) : [...prev, repId]))
  }

  const handleViewProfile = (rep: (typeof initialHearingReps)[0]) => {
    setSelectedRepProfile(rep)
    setShowRepProfileDialog(true)
  }

  const handleDeleteRep = (id: string) => {
    setHearingReps((prevReps) => prevReps.filter((rep) => rep.id !== id))
  }

  const handleAddExternalRep = () => {
    const newRep = {
      id: `HR${hearingReps.length + 1}`,
      name: `New External Rep ${hearingReps.length + 1}`,
      type: "external",
      experience: "0 years",
      hourlyCharge: "$0",
      winRate: "0%",
      specialization: "",
      languages: ["English"],
      education: "",
      caseHistory: "",
    }
    setHearingReps((prevReps) => [...prevReps, newRep])
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Claim Details #{params.id}
            </h1>
            <p className="text-sm text-muted-foreground">Filed on {claimData.filingDate}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isEditing ? (
            <>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={handleSave}>
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </>
          ) : (
            <Button onClick={toggleEdit}>
              <Edit2 className="h-4 w-4 mr-2" />
              Edit Claim
            </Button>
          )}
        </div>
      </div>

      <div className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Claim State</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={claimState} onValueChange={setClaimState} disabled={!isEditing}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Select state" />
              </SelectTrigger>
              <SelectContent>
                {claimStates.map((state) => (
                  <SelectItem key={state.value} value={state.value}>
                    {state.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name</Label>
                <Input id="fullName" defaultValue={claimData.claimantName} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input id="age" defaultValue={claimData.age} disabled={!isEditing} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" defaultValue={claimData.email} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" defaultValue={claimData.phone} disabled={!isEditing} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input id="address" defaultValue={claimData.address} disabled={!isEditing} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="state">State</Label>
                <Input id="state" defaultValue={claimData.state} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input id="zipCode" defaultValue={claimData.zipCode} disabled={!isEditing} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Claim Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="filingDate">Filing Date</Label>
                <Input type="date" id="filingDate" defaultValue={claimData.filingDate} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastWorked">Last Day Worked</Label>
                <Input type="date" id="lastWorked" defaultValue={claimData.lastWorked} disabled={!isEditing} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="reason">Reason for Unemployment</Label>
              <Input id="reason" defaultValue={claimData.reason} disabled={!isEditing} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="weeklyBenefit">Weekly Benefit Amount</Label>
                <Input id="weeklyBenefit" defaultValue={claimData.weeklyBenefit} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currentState">Current State</Label>
                <Select defaultValue={claimData.currentState} disabled={!isEditing}>
                  <SelectTrigger id="currentState">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="initial">Initial Review</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Employer Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="employerName">Employer Name</Label>
              <Input id="employerName" defaultValue={claimData.employerName} disabled={!isEditing} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="employerAddress">Employer Address</Label>
              <Input id="employerAddress" defaultValue={claimData.employerAddress} disabled={!isEditing} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contactPerson">Contact Person</Label>
                <Input id="contactPerson" defaultValue={claimData.contactPerson} disabled={!isEditing} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="employerPhone">Employer Phone</Label>
                <Input id="employerPhone" defaultValue={claimData.employerPhone} disabled={!isEditing} />
              </div>
            </div>
          </CardContent>
        </Card>

        {(claimStatus === "pending" || claimStatus === "in-progress") && (
          <Card>
            <CardHeader>
              <CardTitle>Documents</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Uploaded Documents</span>
                <Button variant="outline" size="sm">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
              </div>
              <div className="space-y-2">
                {claimData.documents.map((doc, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-md">
                    <span className="text-sm">{doc.name}</span>
                    <div>
                      <span className="text-xs text-muted-foreground mr-2">{doc.uploadDate}</span>
                      <Button variant="ghost" size="sm">
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Claim Notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {claimData.notes.map((note, index) => (
              <div key={index} className="p-2 bg-muted rounded-md">
                <p className="text-xs text-muted-foreground mb-1">{note.date}</p>
                <p className="text-sm">{note.content}</p>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Claim Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {claimData.timeline.map((event, index) => (
                <div key={index} className="flex items-center">
                  <div className="flex-shrink-0 w-2 h-2 rounded-full bg-blue-600 mr-4"></div>
                  <div>
                    <p className="font-medium">{event.title}</p>
                    <p className="text-sm text-muted-foreground">{event.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 flex justify-end space-x-4">
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Add Note
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Note</DialogTitle>
              <DialogDescription>
                Add a note to this claim. This will be visible in the claim history.
              </DialogDescription>
            </DialogHeader>
            <Textarea placeholder="Enter your note here..." value={notes} onChange={(e) => setNotes(e.target.value)} />
            <Button onClick={handleAddNote}>Save Note</Button>
          </DialogContent>
        </Dialog>

        {claimStatus === "pending" || claimStatus === "in-progress" ? (
          <Dialog>
            <DialogTrigger asChild>
              <Button>Select Hearing Representatives</Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>Select Hearing Representatives</DialogTitle>
                <DialogDescription>Choose up to two hearing representatives for this claim.</DialogDescription>
              </DialogHeader>
              <div className="flex justify-center space-x-4 mb-4">
                <Button variant={repType === "internal" ? "default" : "outline"} onClick={() => setRepType("internal")}>
                  Internal Reps
                </Button>
                <Button variant={repType === "external" ? "default" : "outline"} onClick={() => setRepType("external")}>
                  External Reps
                </Button>
              </div>
              <ScrollArea className="h-[400px] rounded-md border p-4">
                {filteredHearingReps.map((rep) => (
                  <div key={rep.id} className="flex items-center space-x-4 mb-4">
                    <Checkbox
                      id={rep.id}
                      checked={selectedHearingReps.includes(rep.id)}
                      onCheckedChange={() => handleRepSelection(rep.id)}
                      disabled={selectedHearingReps.length >= 2 && !selectedHearingReps.includes(rep.id)}
                    />
                    <label htmlFor={rep.id} className="flex-grow">
                      <div className="font-medium">{rep.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {rep.type.charAt(0).toUpperCase() + rep.type.slice(1)} • {rep.experience}
                      </div>
                      <div className="text-sm">
                        Hourly Rate: {rep.hourlyCharge} • Win Rate: {rep.winRate}
                      </div>
                    </label>
                    <Button variant="outline" size="sm" onClick={() => handleViewProfile(rep)}>
                      View Profile
                    </Button>
                    {repType === "external" && (
                      <Button variant="destructive" size="sm" onClick={() => handleDeleteRep(rep.id)}>
                        Delete
                      </Button>
                    )}
                  </div>
                ))}
              </ScrollArea>
              {repType === "external" && (
                <Button className="mt-4" onClick={handleAddExternalRep}>
                  Add External Rep
                </Button>
              )}
              <Button onClick={() => console.log("Selected reps:", selectedHearingReps)}>Confirm Selection</Button>
            </DialogContent>
          </Dialog>
        ) : null}
      </div>

      <Dialog open={showRepProfileDialog} onOpenChange={setShowRepProfileDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedRepProfile?.name} - Profile</DialogTitle>
          </DialogHeader>
          {selectedRepProfile && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">Experience</h3>
                <p>{selectedRepProfile.experience}</p>
              </div>
              <div>
                <h3 className="font-semibold">Specialization</h3>
                <p>{selectedRepProfile.specialization}</p>
              </div>
              <div>
                <h3 className="font-semibold">Languages</h3>
                <p>{selectedRepProfile.languages.join(", ")}</p>
              </div>
              <div>
                <h3 className="font-semibold">Education</h3>
                <p>{selectedRepProfile.education}</p>
              </div>
              <div>
                <h3 className="font-semibold">Case History</h3>
                <p>{selectedRepProfile.caseHistory}</p>
              </div>
              <div>
                <h3 className="font-semibold">Hourly Charge</h3>
                <p>{selectedRepProfile.hourlyCharge}</p>
              </div>
              <div>
                <h3 className="font-semibold">Win Rate</h3>
                <p>{selectedRepProfile.winRate}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

