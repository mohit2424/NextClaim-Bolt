"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, X } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

// Sample data - in a real app, this would come from an API
const claims = [
  {
    id: "12345",
    claimantName: "John Doe",
    dateSubmitted: "2024-03-15",
    dueDate: "2 days to go",
    status: "pending",
  },
  {
    id: "67890",
    claimantName: "Jane Smith",
    dateSubmitted: "2024-03-20",
    dueDate: "Overdue",
    status: "overdue",
  },
  {
    id: "11223",
    claimantName: "Alice Johnson",
    dateSubmitted: "2024-03-05",
    dueDate: "5 days to go",
    status: "pending",
  },
  {
    id: "44556",
    claimantName: "Bob Brown",
    dateSubmitted: "2024-03-10",
    dueDate: "7 days to go",
    status: "pending",
  },
]

export default function TotalClaimsPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredClaims = claims.filter(
    (claim) => claim.claimantName.toLowerCase().includes(searchQuery.toLowerCase()) || claim.id.includes(searchQuery),
  )

  return (
    <div className="container mx-auto py-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/dashboard">
              <ChevronLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">Total Claims</h1>
        </div>
        <div className="flex items-center gap-4">
          <Input
            placeholder="Search claims..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-[300px]"
          />
          <Button variant="ghost" size="icon" onClick={() => setSearchQuery("")}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>CLAIM ID</TableHead>
              <TableHead>CLAIMANT NAME</TableHead>
              <TableHead>DATE SUBMITTED</TableHead>
              <TableHead>DUE DATE</TableHead>
              <TableHead>ACTION</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredClaims.map((claim) => (
              <TableRow key={claim.id}>
                <TableCell className="font-medium">{claim.id}</TableCell>
                <TableCell>{claim.claimantName}</TableCell>
                <TableCell>{claim.dateSubmitted}</TableCell>
                <TableCell>
                  <span className={claim.status === "overdue" ? "text-red-500" : "text-yellow-500"}>
                    {claim.dueDate}
                  </span>
                </TableCell>
                <TableCell>
                  <Button variant="outline" size="sm" asChild>
                    <Link href={`/claims/${claim.id}`}>View Details</Link>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

