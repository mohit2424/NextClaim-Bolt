"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Clock, Search, AlertTriangle, CheckCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Footer } from "@/components/Footer"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const deadlines = [
  {
    id: "DL001",
    claimId: "CLM001",
    type: "Document Submission",
    description: "Submit W-2 and last pay stub",
    dueDate: "2024-03-25",
    status: "pending",
    priority: "high",
    assignedTo: "John Smith",
    claimant: "Robert Johnson",
    employer: "Walmart",
  },
  {
    id: "DL002",
    claimId: "CLM002",
    type: "Appeal Filing",
    description: "Last day to file appeal for denial",
    dueDate: "2024-03-28",
    status: "pending",
    priority: "critical",
    assignedTo: "Emily Davis",
    claimant: "Sarah Williams",
    employer: "Target Corporation",
  },
  {
    id: "DL003",
    claimId: "CLM003",
    type: "Hearing Preparation",
    description: "Prepare documentation for unemployment hearing",
    dueDate: "2024-04-01",
    status: "in-progress",
    priority: "medium",
    assignedTo: "Michael Brown",
    claimant: "James Wilson",
    employer: "Home Depot",
  },
  {
    id: "DL004",
    claimId: "CLM004",
    type: "Response Required",
    description: "Employer response to claim filing",
    dueDate: "2024-03-30",
    status: "completed",
    priority: "low",
    assignedTo: "Lisa Anderson",
    claimant: "David Miller",
    employer: "Costco",
  },
  {
    id: "DL005",
    claimId: "CLM005",
    type: "Document Submission",
    description: "Submit medical documentation",
    dueDate: "2024-04-05",
    status: "pending",
    priority: "high",
    assignedTo: "John Smith",
    claimant: "Patricia Brown",
    employer: "Kroger",
  },
]

export default function DeadlinesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState<"dueDate" | "priority">("dueDate")

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "critical":
        return "bg-red-500 text-white"
      case "high":
        return "bg-orange-500 text-white"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-green-500 text-white"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "in-progress":
        return <AlertTriangle className="h-4 w-4 text-orange-500" />
      default:
        return null
    }
  }

  const sortDeadlines = (deadlines: typeof filteredDeadlines) => {
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 }
    return [...deadlines].sort((a, b) => {
      if (sortBy === "priority") {
        return (
          priorityOrder[a.priority as keyof typeof priorityOrder] -
          priorityOrder[b.priority as keyof typeof priorityOrder]
        )
      }
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    })
  }

  const filteredDeadlines = deadlines.filter(
    (deadline) =>
      deadline.claimId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deadline.claimant.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deadline.employer.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto py-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-6 w-6" />
            Deadlines
          </CardTitle>
          <div className="flex items-center gap-4">
            <Select value={sortBy} onValueChange={(value: "dueDate" | "priority") => setSortBy(value)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Sort by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dueDate">Due Date</SelectItem>
                <SelectItem value="priority">Priority</SelectItem>
              </SelectContent>
            </Select>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search deadlines..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-[300px]"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Status</TableHead>
                <TableHead>Claim ID</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead>Assigned To</TableHead>
                <TableHead>Claimant</TableHead>
                <TableHead>Employer</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortDeadlines(filteredDeadlines).map((deadline) => (
                <TableRow key={deadline.id}>
                  <TableCell>{getStatusIcon(deadline.status)}</TableCell>
                  <TableCell className="font-medium">{deadline.claimId}</TableCell>
                  <TableCell>{deadline.type}</TableCell>
                  <TableCell>{deadline.description}</TableCell>
                  <TableCell>{deadline.dueDate}</TableCell>
                  <TableCell>
                    <Badge className={getPriorityColor(deadline.priority)}>{deadline.priority}</Badge>
                  </TableCell>
                  <TableCell>{deadline.assignedTo}</TableCell>
                  <TableCell>{deadline.claimant}</TableCell>
                  <TableCell>{deadline.employer}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      <Footer />
    </div>
  )
}

