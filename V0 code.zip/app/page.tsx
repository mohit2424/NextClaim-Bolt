"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"

const VALID_CREDENTIALS = {
  userCode: "12345",
  password: "nextclaim",
}

export default function LoginPage() {
  const [userCode, setUserCode] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    // Simulate network request
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (userCode === VALID_CREDENTIALS.userCode && password === VALID_CREDENTIALS.password) {
      toast({
        title: "Success",
        description: "Welcome back to NextClaim!",
      })
      router.push("/dashboard")
    } else {
      setError("Invalid user code or password")
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <header className="fixed top-0 left-0 right-0 flex items-center justify-between px-6 py-4 bg-white/80 backdrop-blur-sm border-b">
        <Link href="/" className="flex items-center">
          <h1 className="text-2xl font-bold">NextClaim</h1>
        </Link>
        <Button asChild variant="default">
          <Link href="/contact">Contact Us</Link>
        </Button>
      </header>

      <main className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <form onSubmit={handleSubmit}>
            <CardHeader className="space-y-2 text-center">
              <h1 className="text-3xl font-bold tracking-tight">Welcome Back</h1>
              <p className="text-muted-foreground">
                Effortlessly manage your unemployment claims through our secure platform
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="userCode">User Code</Label>
                <Input
                  id="userCode"
                  placeholder="Enter your user code"
                  value={userCode}
                  onChange={(e) => setUserCode(e.target.value)}
                  required
                  className={error ? "border-red-500" : ""}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className={error ? "border-red-500" : ""}
                />
                {error && <p className="text-sm text-red-500 mt-1">{error}</p>}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox id="remember" />
                  <Label htmlFor="remember" className="text-sm">
                    Remember me
                  </Label>
                </div>
                <Link href="/forgot-password" className="text-sm text-blue-600 hover:underline">
                  Forgot password?
                </Link>
              </div>
              <Button type="submit" className="w-full" size="lg" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign in"}
              </Button>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4 text-center">
              <p className="text-xs text-muted-foreground">
                Your account activity is monitored for security purposes. Ensure your information is up to date for
                seamless processing of claims.
              </p>
              <p className="text-xs text-muted-foreground">Powered by Sails Software</p>
            </CardFooter>
          </form>
        </Card>
      </main>
    </div>
  )
}

