"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react"
import { format, addMonths, subMonths } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"

// Sample claim data with more detailed status information
const claimEvents = {
  "2024-03-15": [
    {
      id: "CLM001",
      type: "Hearing",
      status: "Scheduled",
      claimant: "John Doe",
      employer: "Walmart",
      details: "Initial hearing for unemployment benefits determination",
      time: "10:00 AM",
      location: "Virtual Meeting",
      currentState: "Appeal by Employer",
    },
    {
      id: "CLM002",
      type: "Document Deadline",
      status: "Pending",
      claimant: "Jane Smith",
      employer: "TCS",
      details: "Last day to submit additional documentation",
      currentState: "Determination",
    },
  ],
  "2024-03-20": [
    {
      id: "CLM003",
      type: "Appeal Deadline",
      status: "Upcoming",
      claimant: "Bob Wilson",
      employer: "Amazon",
      details: "Deadline for employer appeal",
      currentState: "Appeal by Employee",
    },
  ],
}

export default function CalendarPage() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date())

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date)
    }
  }

  const selectedDateEvents = claimEvents[format(selectedDate, "yyyy-MM-dd")] || []

  const handlePreviousMonth = () => {
    setCurrentMonth((prev) => subMonths(prev, 1))
  }

  const handleNextMonth = () => {
    setCurrentMonth((prev) => addMonths(prev, 1))
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "scheduled":
        return "bg-blue-500"
      case "pending":
        return "bg-yellow-500"
      case "upcoming":
        return "bg-purple-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStateColor = (state: string) => {
    switch (state.toLowerCase()) {
      case "appeal by employer":
        return "bg-red-500"
      case "appeal by employee":
        return "bg-orange-500"
      case "determination":
        return "bg-green-500"
      case "hearing":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="container mx-auto py-6 pb-16">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-6 w-6" />
            Claims Calendar
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={handlePreviousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <h2 className="text-lg font-semibold">{format(currentMonth, "MMMM yyyy")}</h2>
            <Button variant="outline" size="icon" onClick={handleNextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-6">
            <div className="col-span-5">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                month={currentMonth}
                className="rounded-md border p-4"
                modifiers={{
                  hasEvents: (date) => {
                    const dateStr = format(date, "yyyy-MM-dd")
                    return !!claimEvents[dateStr]
                  },
                }}
                modifiersStyles={{
                  hasEvents: {
                    fontWeight: "bold",
                    backgroundColor: "var(--primary)",
                    color: "white",
                    borderRadius: "50%",
                  },
                }}
              />
            </div>
            <div className="col-span-2">
              <div className="rounded-lg border p-4">
                <h3 className="font-semibold mb-4">Events for {format(selectedDate, "MMMM d, yyyy")}</h3>
                <ScrollArea className="h-[500px] pr-4">
                  <div className="space-y-4">
                    {selectedDateEvents.map((event, index) => (
                      <div key={index} className="rounded-lg border bg-muted/50 p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{event.type}</div>
                          <Badge variant="secondary" className={getStatusColor(event.status)}>
                            {event.status}
                          </Badge>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Claim ID: {event.id}</p>
                          <p className="text-sm text-muted-foreground">Claimant: {event.claimant}</p>
                          <p className="text-sm text-muted-foreground">Employer: {event.employer}</p>
                        </div>
                        <div>
                          <p className="text-sm">{event.details}</p>
                          {event.time && <p className="text-sm text-muted-foreground">Time: {event.time}</p>}
                          {event.location && (
                            <p className="text-sm text-muted-foreground">Location: {event.location}</p>
                          )}
                        </div>
                        <Badge className={getStateColor(event.currentState)}>{event.currentState}</Badge>
                      </div>
                    ))}
                    {selectedDateEvents.length === 0 && (
                      <div className="text-muted-foreground text-center py-8">No events scheduled for this date</div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

