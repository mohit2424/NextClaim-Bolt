"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Building2, Search } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const employers = [
  {
    id: "EMP001",
    name: "Walmart",
    contract: {
      start: "2020-01-01",
      end: "2025-12-31",
    },
    location: "Bentonville, AR",
    industry: "Retail",
    employeeCount: "2.3M",
    activeClaimsCount: 150,
    contact: {
      name: "John Smith",
      email: "john.smith@walmart.com",
      phone: "(555) 123-4567",
    },
    about:
      "Walmart Inc. is an American multinational retail corporation that operates a chain of hypermarkets, discount department stores, and grocery stores.",
  },
  {
    id: "EMP002",
    name: "Target Corporation",
    contract: {
      start: "2021-02-15",
      end: "2026-02-14",
    },
    location: "Minneapolis, MN",
    industry: "Retail",
    employeeCount: "450K",
    activeClaimsCount: 85,
    contact: {
      name: "Sarah Johnson",
      email: "sarah.j@target.com",
      phone: "(555) 234-5678",
    },
    about:
      "Target Corporation is an American retail corporation, serving as one of the largest retailers in the United States.",
  },
  {
    id: "EMP003",
    name: "Home Depot",
    contract: {
      start: "2019-06-01",
      end: "2024-05-31",
    },
    location: "Atlanta, GA",
    industry: "Home Improvement Retail",
    employeeCount: "500K",
    activeClaimsCount: 95,
    contact: {
      name: "Michael Brown",
      email: "m.brown@homedepot.com",
      phone: "(555) 345-6789",
    },
    about:
      "The Home Depot, Inc. is the largest home improvement retailer in the United States, supplying tools, construction products, and services.",
  },
  {
    id: "EMP004",
    name: "Kroger",
    contract: {
      start: "2022-03-01",
      end: "2027-02-28",
    },
    location: "Cincinnati, OH",
    industry: "Retail/Grocery",
    employeeCount: "465K",
    activeClaimsCount: 75,
    contact: {
      name: "David Wilson",
      email: "d.wilson@kroger.com",
      phone: "(555) 456-7890",
    },
    about:
      "The Kroger Co. is an American retail company that operates supermarkets and multi-department stores throughout the United States.",
  },
  {
    id: "EMP005",
    name: "McDonald's Corporation",
    contract: {
      start: "2021-07-15",
      end: "2026-07-14",
    },
    location: "Chicago, IL",
    industry: "Fast Food",
    employeeCount: "200K",
    activeClaimsCount: 120,
    contact: {
      name: "Lisa Anderson",
      email: "l.anderson@mcdonalds.com",
      phone: "(555) 567-8901",
    },
    about:
      "McDonald's Corporation is an American fast food company, operating one of the world's largest restaurant chains.",
  },
  {
    id: "EMP006",
    name: "CVS Health",
    contract: {
      start: "2020-09-01",
      end: "2025-08-31",
    },
    location: "Woonsocket, RI",
    industry: "Healthcare/Retail",
    employeeCount: "300K",
    activeClaimsCount: 65,
    contact: {
      name: "Robert Taylor",
      email: "r.taylor@cvs.com",
      phone: "(555) 678-9012",
    },
    about: "CVS Health Corporation is an American healthcare company that owns CVS Pharmacy, a retail pharmacy chain.",
  },
  {
    id: "EMP007",
    name: "FedEx",
    contract: {
      start: "2023-01-01",
      end: "2027-12-31",
    },
    location: "Memphis, TN",
    industry: "Logistics",
    employeeCount: "550K",
    activeClaimsCount: 90,
    contact: {
      name: "Jennifer Martinez",
      email: "j.martinez@fedex.com",
      phone: "(555) 789-0123",
    },
    about:
      "FedEx Corporation is an American multinational conglomerate holding company focused on transportation, e-commerce, and business services.",
  },
  {
    id: "EMP008",
    name: "Costco Wholesale",
    contract: {
      start: "2022-05-15",
      end: "2027-05-14",
    },
    location: "Issaquah, WA",
    industry: "Retail",
    employeeCount: "280K",
    activeClaimsCount: 45,
    contact: {
      name: "Thomas Wright",
      email: "t.wright@costco.com",
      phone: "(555) 890-1234",
    },
    about:
      "Costco Wholesale Corporation is an American multinational corporation which operates a chain of membership-only big-box retail stores.",
  },
]

export default function EmployersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedEmployer, setSelectedEmployer] = useState<(typeof employers)[0] | null>(null)

  const filteredEmployers = employers.filter(
    (employer) =>
      employer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employer.id.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto py-6 pb-16">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Building2 className="h-6 w-6" />
            Employers
          </CardTitle>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search employers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 w-[300px]"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Contract Period</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Active Claims</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEmployers.map((employer) => (
                <TableRow key={employer.id}>
                  <TableCell>{employer.id}</TableCell>
                  <TableCell className="font-medium">{employer.name}</TableCell>
                  <TableCell>
                    {employer.contract.start} to {employer.contract.end}
                  </TableCell>
                  <TableCell>{employer.location}</TableCell>
                  <TableCell>{employer.activeClaimsCount}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => setSelectedEmployer(employer)}>
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!selectedEmployer} onOpenChange={() => setSelectedEmployer(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Employer Details</DialogTitle>
          </DialogHeader>
          {selectedEmployer && (
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold mb-1">Company Information</h3>
                  <p className="text-sm">ID: {selectedEmployer.id}</p>
                  <p className="text-sm">Name: {selectedEmployer.name}</p>
                  <p className="text-sm">Industry: {selectedEmployer.industry}</p>
                  <p className="text-sm">Location: {selectedEmployer.location}</p>
                  <p className="text-sm">Employees: {selectedEmployer.employeeCount}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Contract Information</h3>
                  <p className="text-sm">Start Date: {selectedEmployer.contract.start}</p>
                  <p className="text-sm">End Date: {selectedEmployer.contract.end}</p>
                  <p className="text-sm">Active Claims: {selectedEmployer.activeClaimsCount}</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-1">Contact Information</h3>
                <p className="text-sm">Name: {selectedEmployer.contact.name}</p>
                <p className="text-sm">Email: {selectedEmployer.contact.email}</p>
                <p className="text-sm">Phone: {selectedEmployer.contact.phone}</p>
              </div>
              <div>
                <h3 className="font-semibold mb-1">About</h3>
                <p className="text-sm">{selectedEmployer.about}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

